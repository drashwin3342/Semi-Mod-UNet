import tkinter as tk
import subprocess
from tkinter import filedialog
from PIL import ImageTk, Image
import argparse
import logging
import os
import cv2
import numpy as np
import torch
import torch.nn.functional as F
from torch.nn.functional import normalize
from torchvision import transforms
from utilss.data_loading import BasicDataset
from unet import UNet
from utilss.utils import plot_img_and_mask
import yaml
import torch.backends.cudnn as cudnn
import archs
from glob import glob
import albumentations as albu #New added
from albumentations.augmentations import transforms
from albumentations.core.composition import Compose
from tqdm import tqdm
from dataset import Dataset
from utils import AverageMeter
from metricss import dice_coef
from metricss import iou_score
from numpy import asarray
from PIL import Image
from miseval import evaluate

print('Launching MedSeg Application...')

def parse_args():
    parser = argparse.ArgumentParser()

    parser.add_argument('--name', default='brain_UNet_woDS',
                        help='model name') # made default from None to covid_UNet_woDS

    args = parser.parse_args()

    return args

def mask_to_image(mask: np.ndarray):
        if mask.ndim == 2:
            return Image.fromarray((mask * 255).astype(np.uint8))
        elif mask.ndim == 3:
            return Image.fromarray((np.argmax(mask, axis=0) * 255 / mask.shape[0]).astype(np.uint8))

class Application(tk.Frame):
    def __init__(self, master=None):
        super().__init__(master)
        self.master = master
        self.create_widgets()
        self.net = None
        self.device = None

    def create_widgets(self):
        self.select_button = tk.Button(self.master, text="Select Image", command=self.select_image)
        self.select_button.pack()
        self.preview_label = tk.Label(self.master)
        self.preview_label.pack()
        self.execute_button = tk.Button(self.master, text="Execute", command=self.execute_code, state='disabled')
        self.execute_button.pack()
        self.result_label = tk.Label(self.master, text="Result:")
        self.result_label.pack()
        self.result_text = tk.Text(self.master, width=50, height=10)
        self.result_text.pack()

    def select_image(self):
        file_path = filedialog.askopenfilename()
        if file_path:
            img = cv2.imread(file_path)
            self.selected_image = img
            self.file_path = file_path
            self.execute_button.configure(state='normal')


    def execute_code(self):
        # # destroy the labels associated with previous images (if they exist)
        # for widget in self.master.winfo_children():
        #     if isinstance(widget, tk.Frame):
        #         widget.destroy()
       
        # destroy any existing image labels
        # for widget in self.preview_label.winfo_children():
        #     widget.destroy()
        # destroy the frame that contains the previous images (if it exists)
        # if hasattr(self, 'image_frame'):
        #     self.image_frame.destroy()
        # if self.image_frame is not None:
        #     self.image_frame.destroy()

        args = parse_args()
        with open('models/%s/config.yml' % args.name, 'r') as f:
            config = yaml.load(f, Loader=yaml.FullLoader)
        print('-'*20)
        for key in config.keys():
            print('%s: %s' % (key, str(config[key])))
        print('-'*20)
        cudnn.benchmark = True
        # create model
        print("=> creating model %s" % config['arch'])
        model = archs.__dict__[config['arch']](config['num_classes'],
                                            config['input_channels'])

        model = model.cuda()
        model.load_state_dict(torch.load('models/%s/model.pth' %
                                        config['name']))
        model.eval()
        val_transform = Compose([
            albu.Resize(config['input_h'], config['input_w']),
            albu.Normalize(),
        ])
        full_img = self.selected_image
   
        img = val_transform(image = np.array(full_img))['image']
        img = img.astype('float32') / 255
        img = img.transpose(2, 0, 1)
     
        img = torch.tensor(img)
       
        img = img.unsqueeze(0)
        
        with torch.no_grad():

            img = img.cuda()
            output = model(img)
            output = torch.sigmoid(output).cpu().numpy()  
            out_filename = os.path.basename(self.file_path)
            cv2.imwrite('UI_Data/brain/Output/0/'+ out_filename,(output[0, 0] * 255).astype('uint8'))
            logging.info(f'Mask saved to {out_filename}')
            if os.path.basename(self.file_path) in os.listdir('UI_Data/brain/GT/0/'):
                #-----------ADDED BELOW for DICE------------------
                y_true = cv2.imread('UI_Data/brain/GT/0/' + os.path.basename(self.file_path), cv2.IMREAD_GRAYSCALE)
                y_pred = cv2.imread('UI_Data/brain/Output/0/'+ os.path.basename(self.file_path), cv2.IMREAD_GRAYSCALE)
                y_pred = cv2.resize(y_pred , (y_true.shape[1],y_true.shape[0]))
                ret, y_true = cv2.threshold(y_true,128,1,cv2.THRESH_BINARY)
                retp, y_pred = cv2.threshold(y_pred,51,1,cv2.THRESH_BINARY) #Threshold at 51 gave best dice
                dice_score = evaluate(y_true, y_pred, metric="DSC") 
                print('Dice Score = ',dice_score)
                jaccard = evaluate(y_true, y_pred, metric="Jaccard")
                print('IoU Score = ',jaccard)
                accuracy = evaluate(y_true, y_pred, metric="ACC") 
                print('Accuracy = ', accuracy)
                #--------------------------------------------------------
            self.result_text.delete("1.0", tk.END)
            self.result_text.tag_configure("bold", font=("TkDefaultFont", 10, "bold"))
            self.result_text.insert(tk.END, f"Prediction for  {out_filename}\n","bold")
            if os.path.basename(self.file_path) in os.listdir('UI_Data/brain/GT/0/'):
                self.result_text.insert(tk.END, f"Dice score =  {str(dice_score)}\n")
                self.result_text.insert(tk.END, f"IoU score =  {str(jaccard)}\n")
                self.result_text.insert(tk.END, f"Accuracy =  {str(accuracy)}\n")

        
        # Show the input image
        # img = Image.open(self.file_path)
        # self.selected_image = img
        # image = self.selected_image
        #print(self.file_path)
        out_filename = os.path.basename(self.file_path)
        image = Image.open(self.file_path)
        predicted_mask = Image.open('UI_Data/brain/Output/0/'+ out_filename)
        predicted_image = Image.fromarray(np.array(predicted_mask))
        if os.path.basename(self.file_path) in os.listdir('UI_Data/brain/GT/0/'):
            GT_mask = Image.open('UI_Data/brain/GT/0/'+ out_filename)
            GT_image = Image.fromarray(np.array(GT_mask))
        
        
        # create a new frame for the images
        image_frame = tk.Frame(self.master)
        #self.image_frame = image_frame
        image_frame.pack(pady=10)
        

        # create labels for each image
        input_img_label = tk.Label(image_frame)
        predicted_img_label = tk.Label(image_frame)
        if os.path.basename(self.file_path) in os.listdir('UI_Data/brain/GT/0/'):
            GT_img_label = tk.Label(image_frame)

        # resize the images to a thumbnail size
        image.thumbnail((256, 256))
        predicted_image.thumbnail((256, 256))
        if os.path.basename(self.file_path) in os.listdir('UI_Data/brain/GT/0/'):
            GT_image.thumbnail((256, 256))

        # create imageTk objects for each image
        self.input_image_tk = ImageTk.PhotoImage(image, name='Input Image')
        self.predicted_image_tk = ImageTk.PhotoImage(predicted_image, name='Predicted Image')
        if os.path.basename(self.file_path) in os.listdir('UI_Data/brain/GT/0/'):
            self.GT_image_tk = ImageTk.PhotoImage(GT_image, name='Ground Truth Image')

        # add the images to the labels
        input_img_label.configure(image=self.input_image_tk)
        predicted_img_label.configure(image=self.predicted_image_tk)
        if os.path.basename(self.file_path) in os.listdir('UI_Data/brain/GT/0/'):
            GT_img_label.configure(image=self.GT_image_tk)
        
        #pdate reference to the new PhotoImage object
        input_img_label.image = self.input_image_tk
        predicted_img_label.image = self.predicted_image_tk
        if os.path.basename(self.file_path) in os.listdir('UI_Data/brain/GT/0/'):
            GT_img_label.image = self.GT_image_tk


        # image_labels = [input_img_label,predicted_img_label,GT_img_label]
        # for i in image_labels:
        #     i.grid_forget()


        # add the labels to the frame with appropriate padding
        #input_img_label.grid_forget()
        input_img_label.grid(row=0, column=0, padx=10, pady=10)
        #predicted_img_label.grid_forget()
        predicted_img_label.grid(row=0, column=1, padx=10, pady=10)
        if os.path.basename(self.file_path) in os.listdir('UI_Data/brain/GT/0/'):
            #GT_img_label.grid_forget()
            GT_img_label.grid(row=0, column=2, padx=10, pady=10)

        # add titles to the labels
        input_label_title = tk.Label(image_frame, text="Input Image")
        predicted_label_title = tk.Label(image_frame, text="Predicted Image")
        if os.path.basename(self.file_path) in os.listdir('UI_Data/brain/GT/0/'):
            GT_label_title = tk.Label(image_frame, text="Ground Truth Image")

        # add the titles to the frame with appropriate padding
        input_label_title.grid(row=1, column=0, padx=10)
        predicted_label_title.grid(row=1, column=1, padx=10)
        if os.path.basename(self.file_path) in os.listdir('UI_Data/brain/GT/0/'):
            GT_label_title.grid(row=1, column=2, padx=10)
        print('App Running')
    

root = tk.Tk()
root.title("Brain Tumor Segmentation")
# create a label widget with some text
my_label = tk.Label(root, text="NIT Patna")
# add the label to the window
my_label.pack()
app = Application(master=root)
app.mainloop()
