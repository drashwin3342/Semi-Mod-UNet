import argparse
import os
from collections import OrderedDict
from glob import glob

import pandas as pd
import torch
import torch.backends.cudnn as cudnn
import torch.nn as nn
import torch.optim as optim
import yaml
import albumentations as albu #New added
from albumentations.augmentations import transforms
from albumentations.core.composition import Compose, OneOf
from sklearn.model_selection import train_test_split
from torch.optim import lr_scheduler
from tqdm import tqdm
import logging
import archs
import losses
from dataset import Dataset
from metrics import iou_score
from utils import AverageMeter, str2bool
from unified_focal_loss_pytorch import AsymmetricUnifiedFocalLoss
from unified_focal_loss_pytorch import AsymmetricFocalLoss
from focalloss import FocalLoss
from focaltversky import FocalTverskyLoss
from iouloss import IoULoss

import torch.optim as optim

ARCH_NAMES = archs.__all__
LOSS_NAMES = losses.__all__
LOSS_NAMES.append('BCEWithLogitsLoss')
LOSS_NAMES.append('UFocalAsym')
LOSS_NAMES.append('AsymFocalLoss')
LOSS_NAMES.append('FocalLoss')
LOSS_NAMES.append('FocalTversky')
LOSS_NAMES.append('IoULoss')

import time
start_time = time.time()
import datetime
current_date_and_time = datetime.datetime.now()
print("The current start date and time is", current_date_and_time)


def parse_args():
    parser = argparse.ArgumentParser()

    parser.add_argument('--name', default=None,
                        help='model name: (default: arch+timestamp)')
    parser.add_argument('--epochs', default=100, type=int, metavar='N',
                        help='number of total epochs to run') #changed from 100 to 20 for faster training
    parser.add_argument('-b', '--batch_size', default=16, type=int,
                        metavar='N', help='mini-batch size (default: 1)') #changed to 1 from 16
    
    # model
    parser.add_argument('--arch', '-a', metavar='ARCH', default='UNet',
                        choices=ARCH_NAMES,
                        help='model architecture: ' +
                        ' | '.join(ARCH_NAMES) +
                        ' (default: UNet)') # Changed from NestedUNet to Unet
    parser.add_argument('--deep_supervision', default=False, type=str2bool)
    parser.add_argument('--input_channels', default=3, type=int,
                        help='input channels')
    parser.add_argument('--num_classes', default=1, type=int,
                        help='number of classelosss') 
    parser.add_argument('--input_w', default=256, type=int,
                        help='image width')
    parser.add_argument('--input_h', default=256, type=int,
                        help='image height')
    
    # loss
    parser.add_argument('--loss', default='BCEDiceLoss',
                        choices=LOSS_NAMES,
                        help='loss: ' +
                        ' | '.join(LOSS_NAMES) +
                        ' (default: BCEDiceLoss)')
    
    # dataset
    parser.add_argument('--dataset', default='brain',
                        help='dataset name') #dataset folder name given covid
    parser.add_argument('--img_ext', default='.png',
                        help='image file extension') #changed from .png
    parser.add_argument('--mask_ext', default='.png',
                        help='mask file extension') #changed from .png

    # optimizer
    parser.add_argument('--optimizer', default='Adam',
                        choices=['Adam', 'SGD', 'RMSProp'],
                        help='loss: ' +
                        ' | '.join(['Adam', 'SGD', 'RMSProp']) +
                        ' (default: Adam)') #Changed from SGD to Adam
    parser.add_argument('--lr', '--learning_rate', default=1e-3, type=float,     #changed from 1e-3 for focal tversky loss: Ashwini
                        metavar='LR', help='initial learning rate')
    parser.add_argument('--momentum', default=0.9, type=float,
                        help='momentum')
    parser.add_argument('--weight_decay', default=1e-4, type=float,
                        help='weight decay')
    parser.add_argument('--nesterov', default=False, type=str2bool,
                        help='nesterov')

    # scheduler
    parser.add_argument('--scheduler', default='CosineAnnealingLR',
                        choices=['CosineAnnealingLR', 'ReduceLROnPlateau', 'MultiStepLR', 'ConstantLR'])
    parser.add_argument('--min_lr', default=1e-5, type=float,
                        help='minimum learning rate')
    parser.add_argument('--factor', default=0.1, type=float)
    parser.add_argument('--patience', default=2, type=int)
    parser.add_argument('--milestones', default='1,2', type=str)
    parser.add_argument('--gamma', default=2/3, type=float)
    parser.add_argument('--early_stopping', default=-1, type=int,
                        metavar='N', help='early stopping (default: -1)')
    
    parser.add_argument('--num_workers', default=4, type=int)

    config = parser.parse_args()

    return config


def train(config, train_loader, model, criterion, optimizer):
    avg_meters = {'loss': AverageMeter(),
                  'iou': AverageMeter()}

    model.train()

    pbar = tqdm(total=len(train_loader))
    for input, target, _ in train_loader:
        input = input.cuda()
        target = target.cuda()

        # compute output
        if config['deep_supervision']:
            outputs = model(input)
            loss = 0
            for output in outputs:
                loss += criterion(output, target)
            loss /= len(outputs)
            iou = iou_score(outputs[-1], target)
        else:
            output = model(input)
            loss = criterion(output, target)
            iou = iou_score(output, target)

        # compute gradient and do optimizing step
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        avg_meters['loss'].update(loss.item(), input.size(0))
        avg_meters['iou'].update(iou, input.size(0))

        postfix = OrderedDict([
            ('loss', avg_meters['loss'].avg),
            ('iou', avg_meters['iou'].avg),
        ])
        pbar.set_postfix(postfix)
        pbar.update(1)
    pbar.close()

    return OrderedDict([('loss', avg_meters['loss'].avg),
                        ('iou', avg_meters['iou'].avg)])


def validate(config, val_loader, model, criterion):
    avg_meters = {'loss': AverageMeter(),
                  'iou': AverageMeter()}

    # switch to evaluate mode
    model.eval()

    with torch.no_grad():
        pbar = tqdm(total=len(val_loader))
        for input, target, _ in val_loader:
            input = input.cuda()
            target = target.cuda()

            # compute output
            if config['deep_supervision']:
                outputs = model(input)
                loss = 0
                for output in outputs:
                    loss += criterion(output, target)
                loss /= len(outputs)
                iou = iou_score(outputs[-1], target)
            else:
                output = model(input)
                loss = criterion(output, target)
                iou = iou_score(output, target)

            avg_meters['loss'].update(loss.item(), input.size(0))
            avg_meters['iou'].update(iou, input.size(0))

            postfix = OrderedDict([
                ('loss', avg_meters['loss'].avg),
                ('iou', avg_meters['iou'].avg),
            ])
            pbar.set_postfix(postfix)
            pbar.update(1)
        pbar.close()

    return OrderedDict([('loss', avg_meters['loss'].avg),
                        ('iou', avg_meters['iou'].avg)])


def main():
    config = vars(parse_args())

    if config['name'] is None:
        if config['deep_supervision']:
            config['name'] = '%s_%s_wDS' % (config['dataset'], config['arch'])
        else:
            config['name'] = '%s_%s_woDS' % (config['dataset'], config['arch'])
    os.makedirs('models/%s' % config['name'], exist_ok=True)

    print('-' * 20)
    for key in config:
        print('%s: %s' % (key, config[key]))
    print('-' * 20)

    with open('models/%s/config.yml' % config['name'], 'w') as f:
        yaml.dump(config, f)

    # define loss function (criterion)
    if config['loss'] == 'BCEWithLogitsLoss':
        criterion = nn.BCEWithLogitsLoss().cuda()
    else:
        criterion = losses.__dict__[config['loss']]().cuda()
    #criterion = nn.CrossEntropyLoss()
    # if config['loss'] == 'UFocalAsym':
    #     criterion = AsymmetricUnifiedFocalLoss().cuda()
    # else:
    #     criterion = losses.__dict__[config['loss']]().cuda()
    
    # if config['loss'] == 'AsymFocalLoss':
    #     criterion = AsymmetricFocalLoss().cuda()
    # else:
    #     criterion = losses.__dict__[config['loss']]().cuda()
   
    # if config['loss'] == 'FocalLoss':
    #     criterion = FocalLoss().cuda()
    # else:
    #     criterion = losses.__dict__[config['loss']]().cuda()

    # if config['loss'] == 'FocalTversky':
    #     criterion = FocalTverskyLoss().cuda()
    # else:
    #     criterion = losses.__dict__[config['loss']]().cuda()
    
    # if config['loss'] == 'IoULoss':
    #     criterion = IoULoss().cuda()
    # else:
    #     criterion = losses.__dict__[config['loss']]().cuda()
    


    cudnn.benchmark = True

    # create model
    print("=> creating model %s" % config['arch'])
    model = archs.__dict__[config['arch']](config['num_classes'],
                                           config['input_channels']) #,
                                           #config['deep_supervision']) #3rd argument hashed for U-Net

    model = model.cuda()

    #Newly Added for training resume. 

    #checkpoint = torch.load('./models/covid_UNet_woDS/model.pth')
    #model.load_state_dict(checkpoint['model'])
    #eph = checkpoint['epoch']
    #best_iou = checkpoint['best_iou']
    #print('Last Epochs = ', eph, ' Last best_iou = ', best_iou)
    # print('Model & last epoch loaded')
    # model.train() # Newly added to ensure these layers are in training mode.
    #model.load_state_dict(torch.load('./models/brain_UNet_woDS/model.pth')) #New added
    #model.train() #New added
    #print('Model loaded') #New added

    params = filter(lambda p: p.requires_grad, model.parameters())
    if config['optimizer'] == 'Adam':
        optimizer = optim.Adam(
            params, lr=config['lr'], weight_decay=config['weight_decay'])
    elif config['optimizer'] == 'SGD':
        optimizer = optim.SGD(params, lr=config['lr'], momentum=config['momentum'],
                              nesterov=config['nesterov'], weight_decay=config['weight_decay'])
    elif config['optimizer'] == 'RMSProp':
        optimizer = optim.RMSprop(model.parameters(), lr=config['lr'], weight_decay=1e-8, momentum=0.9)
    else:
        raise NotImplementedError

    if config['scheduler'] == 'CosineAnnealingLR':
        scheduler = lr_scheduler.CosineAnnealingLR(
            optimizer, T_max=config['epochs'], eta_min=config['min_lr'])
    elif config['scheduler'] == 'ReduceLROnPlateau':
        scheduler = lr_scheduler.ReduceLROnPlateau(optimizer, factor=config['factor'], patience=config['patience'],
                                                   verbose=1, min_lr=config['min_lr'])
    elif config['scheduler'] == 'MultiStepLR':
        scheduler = lr_scheduler.MultiStepLR(optimizer, milestones=[int(e) for e in config['milestones'].split(',')], gamma=config['gamma'])
    elif config['scheduler'] == 'ConstantLR':
        scheduler = None
    else:
        raise NotImplementedError

    # Data loading code
    img_ids = glob(os.path.join('inputs', config['dataset'], 'images', '*' + config['img_ext']))
    img_ids = [os.path.splitext(os.path.basename(p))[0] for p in img_ids]

    train_img_ids, val_img_ids = train_test_split(img_ids, test_size=0.1, random_state=41)

    train_transform = Compose([
        albu.RandomRotate90(),
        albu.Flip(),
        albu.CLAHE(p=0.8),    
         OneOf([
             #albu.HueSaturationValue(),
             albu.RandomBrightness(),
             albu.RandomContrast(),
             albu.RandomGamma()
         ], p=1),
         albu.OneOf([
        albu.ElasticTransform(alpha=120, sigma=120 * 0.05, alpha_affine=120 * 0.03, p=0.5),
        albu.GridDistortion(p=0.5),
        albu.OpticalDistortion(distort_limit=2, shift_limit=0.5, p=1)                  
        ], p=0.8),
        albu.Resize(config['input_h'], config['input_w']),
        albu.Normalize(),
    ])

    val_transform = Compose([
        albu.Resize(config['input_h'], config['input_w']),
        albu.Normalize(),
    ])

    train_dataset = Dataset(
        img_ids=train_img_ids,
        img_dir=os.path.join('inputs', config['dataset'], 'images'),
        mask_dir=os.path.join('inputs', config['dataset'], 'masks'),
        img_ext=config['img_ext'],
        mask_ext=config['mask_ext'],
        num_classes=config['num_classes'],
        transform=train_transform)
    val_dataset = Dataset(
        img_ids=val_img_ids,
        img_dir=os.path.join('inputs', config['dataset'], 'images'),
        mask_dir=os.path.join('inputs', config['dataset'], 'masks'),
        img_ext=config['img_ext'],
        mask_ext=config['mask_ext'],
        num_classes=config['num_classes'],
        transform=val_transform)

    train_loader = torch.utils.data.DataLoader(
        train_dataset,
        batch_size=config['batch_size'],
        shuffle=True,
        num_workers=config['num_workers'],
        drop_last=True)
    val_loader = torch.utils.data.DataLoader(
        val_dataset,
        batch_size=config['batch_size'],
        shuffle=False,
        num_workers=config['num_workers'],
        drop_last=False)

    log = OrderedDict([
        ('epoch', []),
        ('lr', []),
        ('loss', []),
        ('iou', []),
        ('val_loss', []),
        ('val_iou', []),
    ])

    best_iou = 0 #Dont initialize from 0 IF resuming the training
    trigger = 0
    for epoch in range(config['epochs']): #eph + 1,
        print('Epoch [%d/%d]' % (epoch, config['epochs']))

        # train for one epoch
        train_log = train(config, train_loader, model, criterion, optimizer)
        # evaluate on validation set
        val_log = validate(config, val_loader, model, criterion)

        if config['scheduler'] == 'CosineAnnealingLR':
            scheduler.step()
        elif config['scheduler'] == 'ReduceLROnPlateau':
            scheduler.step(val_log['loss'])

        print('loss %.4f - iou %.4f - val_loss %.4f - val_iou %.4f'
              % (train_log['loss'], train_log['iou'], val_log['loss'], val_log['iou']))

        log['epoch'].append(epoch)
        log['lr'].append(config['lr'])
        log['loss'].append(train_log['loss'])
        log['iou'].append(train_log['iou'])
        log['val_loss'].append(val_log['loss'])
        log['val_iou'].append(val_log['iou'])

        pd.DataFrame(log).to_csv('models/%s/log.csv' %
                                 config['name'], index=False)

        trigger += 1

        if val_log['iou'] > best_iou:
            
            #best_iou = val_log['iou'] #shifter this here so that updted best_iou also gets saved. 
            # torch.save({
            # 'epoch': epoch,
            # 'model': model.state_dict(),
            # #'optimizer_state_dict': optimizer.state_dict(),
            # #'loss': loss,
            # 'best_iou': best_iou
            # },'models/%s/model.pth' %
            #            config['name'])  #Newly added to better save & resume model

            torch.save(model.state_dict(), 'models/%s/model.pth' %
                        config['name'])
            best_iou = val_log['iou']
            print("=> saved best model")
            trigger = 0
        print('trigger = ',trigger)
        # early stopping
        if config['early_stopping'] >= 0 and trigger >= config['early_stopping']:
            print("=> early stopping at epoch = ", epoch, " as trigger = ",trigger, " is greater than config['early_stopping] = ", config['early_stopping'])
            break

        torch.cuda.empty_cache()
    
    #Plotting loss curves from log csv file
    #import pandas as pd
    import matplotlib.pyplot as plt
    loc = 'models/brain_UNet_woDS/'
    data = pd.read_csv(loc + 'log.csv')
    plt.figure('Loss Curves')
    plt.title('Loss Curves')
    plt.xlabel('Epochs')
    plt.ylabel('Loss')
    plt.plot(data["epoch"],data["loss"], label = "Training Loss")
    plt.plot(data["epoch"],data["val_loss"], label = "Validation Loss")
    plt.legend(loc="best")
    plt.savefig(loc + 'loss_curve.jpg', dpi = 300) #keep this before plt.show()
    plt.show()


if __name__ == '__main__':
    main()

current_date_and_time = datetime.datetime.now()
print("The current end date and time is", current_date_and_time)
end_time = time.time()
print('Total time taken to run = ',end_time-start_time)