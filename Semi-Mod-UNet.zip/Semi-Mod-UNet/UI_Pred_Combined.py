import tkinter as tk
import subprocess
from tkinter import filedialog
from PIL import ImageTk, Image
import argparse
import logging
import os
import cv2
import numpy as np
import torch
import torch.nn.functional as F
from torch.nn.functional import normalize
from torchvision import transforms
from utilss.data_loading import BasicDataset
from unet import UNet
from utilss.utils import plot_img_and_mask
import yaml
import torch.backends.cudnn as cudnn
import archs
from glob import glob
import albumentations as albu #New added
from albumentations.augmentations import transforms
from albumentations.core.composition import Compose
from tqdm import tqdm
from dataset import Dataset
from utils import AverageMeter
from metricss import dice_coef
from metricss import iou_score
from numpy import asarray
from PIL import Image
from miseval import evaluate

print('Launching MedSeg Application...')

def parse_args():
    parser = argparse.ArgumentParser()

    parser.add_argument('--name', default='ncovid_UNet_woDS',
                        help='model name') # made default from None to covid_UNet_woDS

    args = parser.parse_args()

    return args

# def predict_img(net,
#                 full_img,
#                 device,
#                 scale_factor=1,
#                 out_threshold=0.5):
#     net.eval()
#     img = torch.from_numpy(BasicDataset.preprocess(full_img, scale_factor, is_mask=False))
#     img = img.unsqueeze(0)
#     img = img.to(device=device, dtype=torch.float32)

#     with torch.no_grad():
#         output = net(img)

#         if net.n_classes > 1:
#             probs = F.softmax(output, dim=1)[0]
#         else:
#             probs = torch.sigmoid(output)[0]

#         tf = transforms.Compose([
#             transforms.Resize((full_img.size[1], full_img.size[0]))
        
#         ])

#         full_mask = tf(probs.cpu()).squeeze()

#     if net.n_classes == 1:
#         return (full_mask > out_threshold).numpy()
#     else:
#         return F.one_hot(full_mask.argmax(dim=0), net.n_classes).permute(2, 0, 1).numpy()

# GT_source_path = './Dice_Images/Images/bjorke_9.png'
# Pred_source_path = './Dice_Images/Pred_U-Net/'

def mask_to_image(mask: np.ndarray):
        if mask.ndim == 2:
            return Image.fromarray((mask * 255).astype(np.uint8))
        elif mask.ndim == 3:
            return Image.fromarray((np.argmax(mask, axis=0) * 255 / mask.shape[0]).astype(np.uint8))

class Application(tk.Frame):
    def __init__(self, master=None):
        super().__init__(master)
        self.master = master
        self.create_widgets()
        self.net = None
        self.device = None

    def create_widgets(self):
        self.select_button = tk.Button(self.master, text="Select Image", command=self.select_image)
        self.select_button.pack()
        self.preview_label = tk.Label(self.master)
        self.preview_label.pack()
        self.execute_button = tk.Button(self.master, text="Execute", command=self.execute_code, state='disabled')
        self.execute_button.pack()
        self.result_label = tk.Label(self.master, text="Result:")
        self.result_label.pack()
        self.result_text = tk.Text(self.master, width=50, height=10)
        self.result_text.pack()

    def select_image(self):
        file_path = filedialog.askopenfilename()
        if file_path:
            #img = Image.open(file_path)
            img = cv2.imread(file_path)
            #img.thumbnail((256, 256))
            self.selected_image = img
            self.file_path = file_path
            #img = ImageTk.PhotoImage(img)
            #  # create a label widget with the image and title
            # my_label1 = tk.Label(root, image=img, text="Input Image", compound="top")
            # # add the label to the window
            # my_label1.pack()

            #REMOVED the UPLOADED IMAGE PREVIEW

            # self.preview_label.configure(image=img)
            # self.preview_label.image = img
            self.execute_button.configure(state='normal')


    def execute_code(self):
        # if self.net is None:
        #     self.net = UNet(n_channels=3, n_classes=256, bilinear=False)
        #     print("Loading Model")
        #     self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        #     self.net.to(device=self.device)
        #     self.net.load_state_dict(torch.load('MODEL.pth', map_location=self.device))
        #     logging.info('Model loaded!')
#------------------------------------------------------------------------------------------------
        args = parse_args()

        with open('models/%s/config.yml' % args.name, 'r') as f:
            config = yaml.load(f, Loader=yaml.FullLoader)

        print('-'*20)
        for key in config.keys():
            print('%s: %s' % (key, str(config[key])))
        print('-'*20)

        cudnn.benchmark = True

        # create model
        print("=> creating model %s" % config['arch'])
        model = archs.__dict__[config['arch']](config['num_classes'],
                                            config['input_channels'])

        model = model.cuda()

        model.load_state_dict(torch.load('models/%s/model.pth' %
                                        config['name']))
        model.eval()
        # Data loading code
        # val_img_ids = self.file_path
        # val_img_ids = os.path.basename(val_img_ids) #.rstrip(config['img_ext'])
        #val_img_ids = [os.path.splitext(os.path.basename(p))[0] for p in val_img_ids]
        #print(val_img_ids)
        
        val_transform = Compose([
            albu.Resize(config['input_h'], config['input_w']),
            albu.Normalize(),
        ])
        full_img = self.selected_image
        #print(type(full_img))
        #print(full_img.shape)
        #img = val_transform(full_img)['image']
        img = val_transform(image = np.array(full_img))['image']
        img = img.astype('float32') / 255
        img = img.transpose(2, 0, 1)
        #print(type(img))
        #img = torch.tensor(img)

        #img = torch.from_numpy(BasicDataset.preprocess(full_img, scale = 1.0, is_mask=False))
        #img = BasicDataset.preprocess(full_img, scale = 1.0, is_mask=False)
        #print(type(img))
        #print(img.shape)
        img = torch.tensor(img)
        #print(type(img))
        #print(img.shape)
        #img = val_transform(image=img)
        img = img.unsqueeze(0)
        #img = img.to(device='cuda', dtype=torch.float32)
        
        # print(type(img))
        # print(img.shape)
        # val_dataset = Dataset(
        #     img_ids=val_img_ids,
        #     img_dir=os.path.join('UI_Data', 'Input'),
        #     mask_dir=os.path.join('UI_Data', 'GT'),
        #     img_ext=config['img_ext'],
        #     mask_ext=config['mask_ext'],
        #     num_classes=config['num_classes'],
        #     transform=val_transform)
        # val_loader = torch.utils.data.DataLoader(
        #     val_dataset,
        #     batch_size=1,
        #     shuffle=False,
        #     num_workers=config['num_workers'],
        #     drop_last=False)
        # print(val_loader)
        # #avg_meter = AverageMeter()
        # for input, target in tqdm(val_loader, total=len(val_loader)):
            #with torch.no_grad():
            #img = self.selected_image
            #img = asarray(img)
            #print(img.shape)
            #img = img
        # input = input.cuda
        # target = target.cuda()
        with torch.no_grad():

            img = img.cuda()
            output = model(img)
            # print('output type =', type(output))
            # print('output shape =', output.shape)
            #target = cv2.imread('UI_Data/GT/0/' + os.path.basename(self.file_path))
            
            #target = np.dstack(target) #This is equivalent to concatenation along the third axis after 2-D arrays of shape (M,N) have been reshaped to (M,N,1)
            #target = torch.tensor(target)
            # target = Image.open('UI_Data/GT/0/' + os.path.basename(self.file_path)).convert('L')
            # target = np.array(target)
            # print('target type =', type(target))
            # print('target shape =', target.shape)
            #target = val_transform(image = target)['image']
            #target = target.astype('float32') / 255
            #target = target.transpose(2, 0, 1)
            # print('Now target type =', type(target))
            # print('Now target shape =', target.shape)
            #target = np.mean(target, axis=0)

            #target = torch.tensor(target)
            #target = target.unsqueeze(0)
            # print('Now Now target type =', type(target))
            # print('Now Now target shape =', target.shape)
            # avg_meter.update(dice, input.size(0))
            #
            #output1 = output
            #target = target
            # target = normalize(target)
            # output1 = normalize(output1)
            #target = (target>127.0).float()
            #output1 = (output1>0.0).float()
            #print(target[60:80,60:80])
            #print(output1)
            # #output1 = output1*255
            # print('Now output type =', type(output1))
            # print('Now output shape =', output1.shape)
            #iou = iou_score(output1, target)
            #dice = dice_coef(output1, target)
            #print('Dice Coef = ', dice)
            #print('IoU = ', iou)
            
            output = torch.sigmoid(output).cpu().numpy()  
            #output = torch.softmax(output, dim=0).cpu().numpy() #(Used Softmax to make masks multi-class and normalising the first axix of output tensor)
            #output = torch.tanh(output) #.cpu().numpy()
            #output = output.cpu().numpy()
            

            #cv2.imwrite('UI_Data/Output/0'+os.path.basename(self.file_path), (output * 255).astype('uint8'))
            #print('IoU: %.4f' % avg_meter.avg)
            #print('Dice: %.4f' % avg_meter.avg)

            #torch.cuda.empty_cache()

    #-------------------------------------------------------------------------------------------------------


        
            # mask = predict_img(net=self.net,
            #                    full_img=img,
            #                    scale_factor=0.5,
            #                    out_threshold=0.5,
            #                    device=self.device)

            # Save the predicted mask
            out_filename = os.path.basename(self.file_path)
            #cv2.imwrite(('UI_Data/Output/'+ out_filename), (output*255).astype('uint8'))
            #----------------------------------------------------------           
            # print(type(output))
            # print(output.shape)
            # output = np.squeeze(output)
            #                                     #output = (output*255).astype('uint8')
            # print(output.shape)
            # result = mask_to_image(output)
            # print(type(result))
            #----------------------------------------
            #output = np.squeeze(output)
            #result = Image.fromarray(output)
            # ----------------------    
            #result.save('UI_Data/Output/0/'+ out_filename)
            #-------------------------------
            #print(len(output))
            cv2.imwrite('UI_Data/Output/0/'+ out_filename,(output[0, 0] * 255).astype('uint8'))

            logging.info(f'Mask saved to {out_filename}')

            if os.path.basename(self.file_path) in os.listdir('UI_Data/GT/0/'):
                #-----------ADDED BELOW for DICE------------------
                y_true = cv2.imread('UI_Data/GT/0/' + os.path.basename(self.file_path), cv2.IMREAD_GRAYSCALE)
                y_pred = cv2.imread('UI_Data/Output/0/'+ os.path.basename(self.file_path), cv2.IMREAD_GRAYSCALE)
                y_pred = cv2.resize(y_pred , (y_true.shape[1],y_true.shape[0]))
                ret, y_true = cv2.threshold(y_true,128,1,cv2.THRESH_BINARY)
                retp, y_pred = cv2.threshold(y_pred,51,1,cv2.THRESH_BINARY) #Threshold at 51 gave best dice
                dice_score = evaluate(y_true, y_pred, metric="DSC") 
                print('Dice Score = ',dice_score)
                jaccard = evaluate(y_true, y_pred, metric="Jaccard")
                print('IoU Score = ',jaccard)
                accuracy = evaluate(y_true, y_pred, metric="ACC") 
                print('Accuracy = ', accuracy)
                #--------------------------------------------------------


            self.result_text.delete("1.0", tk.END)
            self.result_text.tag_configure("bold", font=("TkDefaultFont", 10, "bold"))
            self.result_text.insert(tk.END, f"Prediction for  {out_filename}\n","bold")
            if os.path.basename(self.file_path) in os.listdir('UI_Data/GT/0/'):
                self.result_text.insert(tk.END, f"Dice score =  {str(dice_score)}\n")
                self.result_text.insert(tk.END, f"IoU score =  {str(jaccard)}\n")
                self.result_text.insert(tk.END, f"Accuracy =  {str(accuracy)}\n")

    # Load the predicted mask & GT
        
        # Show the input image
        img = Image.open(self.file_path)
        self.selected_image = img
        image = self.selected_image
        input_img_label = tk.Label(self.master)
        #input_img_label.pack()

        #For adding label, Create a tkinter window and canvas to display the image
        # root = tk.Tk()
        # canvas = tk.Canvas(root, width=image.width, height=image.height)
        # canvas.pack()


        image.thumbnail((250, 250))   #TEMPORARILY HASHED IT

        input_image_tk = ImageTk.PhotoImage(image, name='Input Image')

        #Add the image to the canvas:
        #canvas.create_image(0, 0, image=input_image_tk, anchor='nw')

        # Create a label widget and add it to the canvas:
        # label = tk.Label(root, text='Input Image', bg='white', fg='black')
        # label.place(x=10, y=10)


        # create a label widget with the image and title
        #root = tk.Tk()
        my_label1 = tk.Label(root, image=input_image_tk, text="Input Image", compound="top")
        # add the label to the window
        my_label1.pack()
        input_img_label.configure(image=input_image_tk)
        input_img_label.image = input_image_tk
        
        # Show the predicted image
        predicted_mask = Image.open('UI_Data/Output/0/'+ out_filename)
        # Apply the mask on the original image
        #predicted_image = Image.fromarray(np.array(input)*np.array(predicted_mask)[:,:,np.newaxis])
        predicted_image = Image.fromarray(np.array(predicted_mask))
        predicted_img_label = tk.Label(self.master)
        #predicted_img_label.pack()
        predicted_image.thumbnail((250, 250))
        predicted_image_tk = ImageTk.PhotoImage(predicted_image, name='Predicted Image')
        # create a label widget with the image and title
        #root = tk.Tk()
        my_label2 = tk.Label(root, image=predicted_image_tk, text="Predicted Image", compound="top")
        # add the label to the window
        my_label2.pack()
        predicted_img_label.configure(image=predicted_image_tk)
        predicted_img_label.image = predicted_image_tk

        if os.path.basename(self.file_path) in os.listdir('UI_Data/GT/0/'):
            #Show the GT Image
            GT_mask = Image.open('UI_Data/GT/0/'+ out_filename)
            GT_image = Image.fromarray(np.array(GT_mask))
            GT_img_label = tk.Label(self.master)
            #GT_img_label.pack()
            GT_image.thumbnail((250, 250))
            GT_image_tk = ImageTk.PhotoImage(GT_image, name='Ground Truth Image')
            # create a label widget with the image and title
            #root = tk.Tk()
            my_label3 = tk.Label(root, image=GT_image_tk, text="Ground Truth Image", compound="top")
            # add the label to the window
            my_label3.pack()
            GT_img_label.configure(image=GT_image_tk)
            GT_img_label.image = GT_image_tk
        print('Test Done')

root = tk.Tk()
root.title("MedSeg with Mod-UNet")
# create a label widget with some text
my_label = tk.Label(root, text="Created by Ashwini Kumar Upadhyay, NIT Patna")
# add the label to the window
my_label.pack()
# my_label = tk.Label(root, text="National Institute of Technology Patna")
# # add the label to the window
# my_label.pack()
app = Application(master=root)
app.mainloop()
