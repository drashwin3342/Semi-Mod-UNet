# -*- coding: utf-8 -*-

"""Preview
Code for 'Inf-Net: Automatic COVID-19 Lung Infection Segmentation from CT Scans'
submit to Transactions on Medical Imaging, 2020.

First Version: Created on 2020-05-13 (@author: Ge-Peng Ji)
"""
#-------------Import from UNet train.py-----------
import argparse
import os
from cv2 import resize
import pandas as pd
import logging
import sys
from pathlib import Path
from PIL import Image
from collections import OrderedDict
from glob import glob

import pandas as pd
import torch
import torch.backends.cudnn as cudnn
import torch.nn as nn
import torch.optim as optim
import yaml
import albumentations as albu #New added
from albumentations.augmentations import transforms
from albumentations.core.composition import Compose, OneOf
from sklearn.model_selection import train_test_split
from torch.optim import lr_scheduler
from tqdm import tqdm
import logging
import archs
import losses
from dataset import Dataset
from metrics import iou_score
from utils import AverageMeter, str2bool
import torch.nn as nn
import torch.nn.functional as F
from torchvision import transforms
import wandb
from torch import optim
from torch.utils.data import DataLoader, random_split
from tqdm import tqdm

from utilss.data_loading import BasicDataset
from utilss.dice_score import dice_loss
from evaluate import evaluate
from unet import UNet
from metrics import iou_score
from metrics import dice_coef

# dir_img = Path('./inputs/DataPrepare/Hybrid-label/Imgs/')
# dir_mask = Path('./inputs/DataPrepare/Hybrid-label/GT/')
# dir_checkpoint = Path('./models/semi_training/')

# -----------------------------------------------

# ---- base lib -----
import os
import argparse
from datetime import datetime
import cv2
import numpy as np
import random
import shutil
from scipy import misc
# ---- torch lib ----
import torch
from torch.autograd import Variable
import torch.nn.functional as F
# ---- custom lib ----
# NOTES: Here we nly provide Res2Net, you can also replace it with other backbones
#from unet import UNet as Network
#from Code.model_lung_infection.InfNet_Res2Net import Inf_Net as Network
#from Code.utils.dataloader_LungInf import get_loader, test_dataset
#from Code.utils.utils import clip_gradient, adjust_lr, AvgMeter
#from Code.utils.format_conversion import binary2edge

#-------------------New Added from UNet train.py---------------------------
ARCH_NAMES = archs.__all__
LOSS_NAMES = losses.__all__
LOSS_NAMES.append('BCEWithLogitsLoss')


def parse_args():
    parser = argparse.ArgumentParser()

    parser.add_argument('--name', default='covid_UNet_woDS',
                        help='model name: (default: arch+timestamp)')
    parser.add_argument('--epochs', default=10, type=int, metavar='N',
                        help='number of total epochs to run') #changed from 100 to 10 for Pseudo Training
    parser.add_argument('-b', '--batch_size', default=48, type=int,
                        metavar='N', help='mini-batch size (default: 1)') #changed to 16 from 1
    
    # model
    parser.add_argument('--arch', '-a', metavar='ARCH', default='UNet',
                        choices=ARCH_NAMES,
                        help='model architecture: ' +
                        ' | '.join(ARCH_NAMES) +
                        ' (default: UNet)') # Changed from NestedUNet to Unet
    parser.add_argument('--deep_supervision', default=False, type=str2bool)
    parser.add_argument('--input_channels', default=3, type=int,
                        help='input channels')
    parser.add_argument('--num_classes', default=1, type=int,
                        help='number of classelosss') 
    parser.add_argument('--input_w', default=192, type=int,
                        help='image width')
    parser.add_argument('--input_h', default=192, type=int,
                        help='image height')
    
    # loss
    parser.add_argument('--loss', default='BCEDiceLoss',
                        choices=LOSS_NAMES,
                        help='loss: ' +
                        ' | '.join(LOSS_NAMES) +
                        ' (default: BCEDiceLoss)')
    
    # dataset
    parser.add_argument('--dataset', default='covid',
                        help='dataset name') #dataset folder name given covid
    parser.add_argument('--img_ext', default='.jpg',
                        help='image file extension') #changed from .png
    parser.add_argument('--mask_ext', default='.png',
                        help='mask file extension') #changed from .png

    # optimizer
    parser.add_argument('--optimizer', default='Adam',
                        choices=['Adam', 'SGD', 'RMSProp'],
                        help='loss: ' +
                        ' | '.join(['Adam', 'SGD', 'RMSProp']) +
                        ' (default: Adam)') #Changed from SGD to Adam
    parser.add_argument('--lr', '--learning_rate', default=1e-3, type=float,
                        metavar='LR', help='initial learning rate')
    parser.add_argument('--momentum', default=0.9, type=float,
                        help='momentum')
    parser.add_argument('--weight_decay', default=1e-4, type=float,
                        help='weight decay')
    parser.add_argument('--nesterov', default=False, type=str2bool,
                        help='nesterov')

    # scheduler
    parser.add_argument('--scheduler', default='CosineAnnealingLR',
                        choices=['CosineAnnealingLR', 'ReduceLROnPlateau', 'MultiStepLR', 'ConstantLR'])
    parser.add_argument('--min_lr', default=1e-5, type=float,
                        help='minimum learning rate')
    parser.add_argument('--factor', default=0.1, type=float)
    parser.add_argument('--patience', default=2, type=int)
    parser.add_argument('--milestones', default='1,2', type=str)
    parser.add_argument('--gamma', default=2/3, type=float)
    parser.add_argument('--early_stopping', default=-1, type=int,
                        metavar='N', help='early stopping (default: -1)')
    
    parser.add_argument('--num_workers', default=4, type=int)
    #parser.add_argument('--train_path', type=str, default=_train_path) #New Added
    #parser.add_argument('--train_save', type=str, default=_train_save) #New Added

    config = parser.parse_args()

    return config


def train(config, train_loader, model, criterion, optimizer):
    avg_meters = {'loss': AverageMeter(),
                  'iou': AverageMeter()}
      
    model.train()

    pbar = tqdm(total=len(train_loader))
    for input, target, _ in train_loader:
        input = input.cuda()
        target = target.cuda()

        # compute output
        if config['deep_supervision']:
            outputs = model(input)
            loss = 0
            for output in outputs:
                loss += criterion(output, target)
            loss /= len(outputs)
            iou = iou_score(outputs[-1], target)
        else:
            output = model(input)
            loss = criterion(output, target)
            iou = iou_score(output, target)

        # compute gradient and do optimizing step
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        avg_meters['loss'].update(loss.item(), input.size(0))
        avg_meters['iou'].update(iou, input.size(0))

        postfix = OrderedDict([
            ('loss', avg_meters['loss'].avg),
            ('iou', avg_meters['iou'].avg),
        ])
        pbar.set_postfix(postfix)
        pbar.update(1)
    pbar.close()

    return OrderedDict([('loss', avg_meters['loss'].avg),
                        ('iou', avg_meters['iou'].avg)])


def validate(config, val_loader, model, criterion):
    avg_meters = {'loss': AverageMeter(),
                  'iou': AverageMeter()}

    # switch to evaluate mode
    model.eval()

    with torch.no_grad():
        pbar = tqdm(total=len(val_loader))
        for input, target, _ in val_loader:
            input = input.cuda()
            target = target.cuda()

            # compute output
            if config['deep_supervision']:
                outputs = model(input)
                loss = 0
                for output in outputs:
                    loss += criterion(output, target)
                loss /= len(outputs)
                iou = iou_score(outputs[-1], target)
            else:
                output = model(input)
                loss = criterion(output, target)
                iou = iou_score(output, target)

            avg_meters['loss'].update(loss.item(), input.size(0))
            avg_meters['iou'].update(iou, input.size(0))

            postfix = OrderedDict([
                ('loss', avg_meters['loss'].avg),
                ('iou', avg_meters['iou'].avg),
            ])
            pbar.set_postfix(postfix)
            pbar.update(1)
        pbar.close()

    return OrderedDict([('loss', avg_meters['loss'].avg),
                        ('iou', avg_meters['iou'].avg)])


def train_module(_train_path, _train_save, _resume_snapshot): #Added (_train_path, _train_save, _resume_snapshot)
    config = vars(parse_args())

    if config['name'] is None:
        if config['deep_supervision']:
            config['name'] = '%s_%s_wDS' % (config['dataset'], config['arch'])
        else:
            config['name'] = '%s_%s_woDS' % (config['dataset'], config['arch'])
    os.makedirs('models/%s' % config['name'], exist_ok=True)

    print('-' * 20)
    for key in config:
        print('%s: %s' % (key, config[key]))
    print('-' * 20)

    with open('models/%s/config.yml' % config['name'], 'w') as f:
        yaml.dump(config, f)

    # define loss function (criterion)
    if config['loss'] == 'BCEWithLogitsLoss':
        criterion = nn.BCEWithLogitsLoss().cuda()
    else:
        criterion = losses.__dict__[config['loss']]().cuda()

    cudnn.benchmark = True

    # create model
    print("=> creating model %s" % config['arch'])
    model = archs.__dict__[config['arch']](config['num_classes'],
                                           config['input_channels']) #,
                                           #config['deep_supervision']) #3rd argument hashed for U-Net

    model = model.cuda()
    model.load_state_dict(torch.load(_resume_snapshot)) #New added
    model.train() #New added
    print('Model loaded from ' + _resume_snapshot) #New added
    
    params = filter(lambda p: p.requires_grad, model.parameters())
    if config['optimizer'] == 'Adam':
        optimizer = optim.Adam(
            params, lr=config['lr'], weight_decay=config['weight_decay'])
    elif config['optimizer'] == 'SGD':
        optimizer = optim.SGD(params, lr=config['lr'], momentum=config['momentum'],
                              nesterov=config['nesterov'], weight_decay=config['weight_decay'])
    elif config['optimizer'] == 'RMSProp':
        optimizer = optim.RMSprop(model.parameters(), lr=config['lr'], weight_decay=1e-8, momentum=0.9)
    else:
        raise NotImplementedError

    if config['scheduler'] == 'CosineAnnealingLR':
        scheduler = lr_scheduler.CosineAnnealingLR(
            optimizer, T_max=config['epochs'], eta_min=config['min_lr'])
    elif config['scheduler'] == 'ReduceLROnPlateau':
        scheduler = lr_scheduler.ReduceLROnPlateau(optimizer, factor=config['factor'], patience=config['patience'],
                                                   verbose=1, min_lr=config['min_lr'])
    elif config['scheduler'] == 'MultiStepLR':
        scheduler = lr_scheduler.MultiStepLR(optimizer, milestones=[int(e) for e in config['milestones'].split(',')], gamma=config['gamma'])
    elif config['scheduler'] == 'ConstantLR':
        scheduler = None
    else:
        raise NotImplementedError

    # Data loading code
    img_ids = glob(os.path.join('{}/'.format(_train_path),'images', '*' + config['img_ext']))
    img_ids = [os.path.splitext(os.path.basename(p))[0] for p in img_ids]

    train_img_ids, val_img_ids = train_test_split(img_ids, test_size=0.1, random_state=41)

    train_transform = Compose([
        albu.RandomRotate90(),
        albu.Flip(),
         OneOf([
             albu.HueSaturationValue(),
             albu.RandomBrightness(),
             albu.RandomContrast(),
         ], p=1),
        albu.Resize(config['input_h'], config['input_w']),
        albu.Normalize(),
    ])

    val_transform = Compose([
        albu.Resize(config['input_h'], config['input_w']),
        albu.Normalize(),
    ])

    train_dataset = Dataset(
        img_ids=train_img_ids,
        img_dir=os.path.join('inputs', config['dataset'],'DataPrepare','Hybrid-label', 'images'),
        mask_dir=os.path.join('inputs', config['dataset'], 'DataPrepare','Hybrid-label', 'masks'),
        img_ext=config['img_ext'],
        mask_ext=config['mask_ext'],
        num_classes=config['num_classes'],
        transform=train_transform)
    val_dataset = Dataset(
        img_ids=val_img_ids,
        img_dir=os.path.join('inputs', config['dataset'],'DataPrepare','Hybrid-label', 'images'),
        mask_dir=os.path.join('inputs', config['dataset'],'DataPrepare','Hybrid-label', 'masks'),
        img_ext=config['img_ext'],
        mask_ext=config['mask_ext'],
        num_classes=config['num_classes'],
        transform=val_transform)

    train_loader = torch.utils.data.DataLoader(
        train_dataset,
        batch_size=config['batch_size'],
        shuffle=True,
        num_workers=config['num_workers'],
        drop_last=True)
    val_loader = torch.utils.data.DataLoader(
        val_dataset,
        batch_size=config['batch_size'],
        shuffle=False,
        num_workers=config['num_workers'],
        drop_last=False)

    log = OrderedDict([
        ('epoch', []),
        ('lr', []),
        ('loss', []),
        ('iou', []),
        ('val_loss', []),
        ('val_iou', []),
    ])

    best_iou = 0
    trigger = 0
    for epoch in range(config['epochs']):
        print('Epoch [%d/%d]' % (epoch, config['epochs']))

        # train for one epoch
        train_log = train(config, train_loader, model, criterion, optimizer)
        # evaluate on validation set
        val_log = validate(config, val_loader, model, criterion)

        if config['scheduler'] == 'CosineAnnealingLR':
            scheduler.step()
        elif config['scheduler'] == 'ReduceLROnPlateau':
            scheduler.step(val_log['loss'])

        print('loss %.4f - iou %.4f - val_loss %.4f - val_iou %.4f'
              % (train_log['loss'], train_log['iou'], val_log['loss'], val_log['iou']))

        log['epoch'].append(epoch)
        log['lr'].append(config['lr'])
        log['loss'].append(train_log['loss'])
        log['iou'].append(train_log['iou'])
        log['val_loss'].append(val_log['loss'])
        log['val_iou'].append(val_log['iou'])

        pd.DataFrame(log).to_csv('models/%s/log.csv' %
                                 config['name'], index=False)

        trigger += 1
        
        #Saving Model
        # if val_log['iou'] > best_iou:
        #     if (epoch+1) % 10 == 0:  # % gives remainder
        #         torch.save(model.state_dict(), save_path + 'model%d.pth' % (epoch+1))
        #         print('[Saving Snapshot:]', save_path + 'model%d.pth' % (epoch+1))
        #     best_iou = val_log['iou']
        #     print("=> saved best model")
        #     trigger = 0

        save_path = 'models/{}/'.format(_train_save)
        os.makedirs(save_path, exist_ok=True)

        if (epoch+1) % 10 == 0:  # % gives remainder
            torch.save(model.state_dict(), save_path + 'model%d.pth' % (epoch+1))
            print('[Saving Snapshot:]', save_path + 'model%d.pth' % (epoch+1))
            print('Model Saved to ' + save_path + 'model10.pth')

        # early stopping
        if config['early_stopping'] >= 0 and trigger >= config['early_stopping']:
            print("=> early stopping")
            break

        torch.cuda.empty_cache()



#---------- Above takenfrom train.py------------------------------

#---------- Below Taken from val.py --------------

# def parse_args():
#     parser = argparse.ArgumentParser()

#     parser.add_argument('--name', default='covid_UNet_woDS',
#                         help='model name') # made default from None to covid_UNet_woDS

#     args = parser.parse_args()

#     return args


def inference_module(_data_path, _save_path, _pth_path):
    
    os.makedirs(_save_path, exist_ok=True) #New added
    config = parse_args()

    with open('models/%s/config.yml' % config.name, 'r') as f:
        config = yaml.load(f, Loader=yaml.FullLoader)

    print('-'*20)
    for key in config.keys():
        print('%s: %s' % (key, str(config[key])))
    print('-'*20)

    cudnn.benchmark = True

    # create model
    print("=> creating model %s" % config['arch'])
    model = archs.__dict__[config['arch']](config['num_classes'],
                                           config['input_channels']) #,
                                           #config['deep_supervision']) #3rd argument hashed for U-Net

    model = model.cuda()

    #Data loading code
    #GT_source_path = '{}/'.format(_data_path)
    Pred_source_path = '{}/'.format(_save_path)
    #GT_imgs = os.listdir(_data_path)

    val_img_ids = glob(os.path.join(_data_path, '*' + config['img_ext']))
    print(val_img_ids)
    val_img_ids = [os.path.splitext(os.path.basename(p))[0] for p in val_img_ids]
    print(val_img_ids)
    #full_image = Image.open(_data_path, '*' + config['img_ext'])

    #_, val_img_ids = train_test_split(img_ids, test_size=0.96, random_state=41)

    model.load_state_dict(torch.load(_pth_path)) #Changed
    print('Model Loaded from ' + snapshot_dir)
    model.eval()

    val_transform = Compose([
        albu.Resize(config['input_h'], config['input_w']), # config['input_h'], config['input_w']
        albu.Normalize()
     ])

    val_dataset = Dataset(
        img_ids=val_img_ids,
        img_dir= _data_path, #Changed
        mask_dir= './inputs/covid/DataPrepare/inf_split_mask', #Crack code: mask_dir = _data_path done to suppress error. 
        img_ext=config['img_ext'],
        mask_ext=config['mask_ext'],
        num_classes=config['num_classes'],
        transform=val_transform)
    val_loader = torch.utils.data.DataLoader(
        val_dataset,
        batch_size=config['batch_size'],
        shuffle=False,
        num_workers=config['num_workers'],
        drop_last=False)

    #avg_meter = AverageMeter()

    for c in range(config['num_classes']):
        os.makedirs(Pred_source_path, exist_ok=True)
    with torch.no_grad():
        for input, target, meta in tqdm(val_loader, total=len(val_loader)):
            input = input.cuda()
            target = target.cuda()

            # compute output
            if config['deep_supervision']:
                output = model(input)[-1]
            else:
                output = model(input)

            # iou = iou_score(output, target)
            # avg_meter.update(iou, input.size(0))
            
            #dice = dice_coef(output,target)
            #avg_meter.update(dice, input.size(0))

            output = torch.sigmoid(output).cpu().numpy()

            for i in range(len(output)):
                for c in range(config['num_classes']):
                    cv2.imwrite(os.path.join(Pred_source_path, meta['img_id'][i] + '.png'),
                                (output[i, c] * 255).astype('uint8'))

    #print('IoU: %.4f' % avg_meter.avg)
    #print('Dice: %.4f' % avg_meter.avg)

    torch.cuda.empty_cache()

#-----------------------------------------------------------------------------------

#------------PseudoGeneration Part---------------------------

def movefiles(_src_dir, _dst_dir):
    os.makedirs(_dst_dir, exist_ok=True)
    for file_name in os.listdir(_src_dir):
        shutil.copyfile(os.path.join(_src_dir, file_name),
                        os.path.join(_dst_dir, file_name))


if __name__ == '__main__':
    slices = './inputs/covid/DataPrepare'
    slices_dir = slices + '/Imgs_split'
    slices_pred_seg_dir = slices + '/pred_seg_split'
    #slices_pred_edge_dir = slices + '/pred_edge_split'

    # NOTES: Hybrid-label = Doctor-label + Pseudo-label
    semi = './inputs/covid/DataPrepare/Hybrid-label'
    semi_img = semi + '/images'
    semi_mask = semi + '/masks/0'
    #semi_edge = semi + '/Edge'

    if (not os.path.exists(semi_img)) or (len(os.listdir(semi_img)) != 50):
        shutil.copytree('inputs/covid/images',
                        semi_img)
        shutil.copytree('inputs/covid/masks/0',
                        semi_mask)
        #shutil.copytree('Dataset/TrainingSet/LungInfection-Train/Doctor-label/Edge',
                        #semi_edge)
        print('Copy done')
    else:
        print('Check done')

    slices_lst = os.listdir(slices_dir)
    random.shuffle(slices_lst)

    print("#" * 20, "\nStart Training (U-Net)\nThis code is written for 'U-Net: Automatic COVID-19 Lung "
                    "Infection Segmentation from CT Scans', 2020, arXiv.\n"
                    "----\nPlease cite the paper if you use this code and dataset. "
                    "And any questions feel free to contact me "
                    "via E-mail (ashwiniu.ph21.ec@nitp.ac.in)\n----\n", "#" * 20)

    for i, split_name in enumerate(slices_lst):
        print('\n[INFO] {} ({}/320)'.format(split_name, i)) #change back to 20 from 320 for working with 20 slices
        # ---- inference ----
        test_aux_dir = os.path.join(slices_dir, split_name)
        test_aux_save_dir = os.path.join(slices_pred_seg_dir, split_name)
        if i == 0:
            snapshot_dir = './model.pth'
        else:
            snapshot_dir = './models/semi_training/model{}/model10.pth'.format(i-1)

        inference_module(_data_path=test_aux_dir, _save_path=test_aux_save_dir, _pth_path=snapshot_dir)

        #os.makedirs(os.path.join(slices_pred_seg_dir, split_name), exist_ok=True)
        # for pred_name in os.listdir(test_aux_save_dir):
        #     edge_tmp = binary2edge(os.path.join(test_aux_save_dir, pred_name))
        #     cv2.imwrite(os.path.join(slices_pred_seg_dir, split_name, pred_name), edge_tmp)

        # ---- move generation ----
        movefiles(test_aux_dir, semi_img)
        movefiles(test_aux_save_dir, semi_mask)
        #movefiles(os.path.join(slices_pred_edge_dir, split_name), semi_edge)

        # ---- training ----
        train_module(_train_path=semi,
                     _train_save='semi_training/model{}'.format(i),
                     _resume_snapshot=snapshot_dir)

    # move img/pseudo-label into `./Dataset/TrainingSet/LungInfection-Train/Pseudo-label`
    # import shutil
    # semi = './data/DataPrepare/Hybrid-label'
    # semi_img = semi + '/Imgs'
    # semi_mask = semi + '/GT'
    shutil.copytree(semi_img, './inputs/covid/Pseudo/images')
    shutil.copytree(semi_mask, './inputs/covid/Pseudo/masks/0')
    #shutil.copytree(semi_edge, 'Dataset/TrainingSet/LungInfection-Train/Pseudo-label/Edge')
    print('Pseudo Label Generated!')
