a = 'Ashwini'
print(a, "is an Engineer")