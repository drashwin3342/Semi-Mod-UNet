import argparse
import os
from glob import glob
import numpy as np
import cv2
import torch
import torch.backends.cudnn as cudnn
import yaml
import albumentations as albu #New added
from albumentations.augmentations import transforms
from albumentations.core.composition import Compose
from sklearn.model_selection import train_test_split
from tqdm import tqdm
from thop import profile
import csv
import archs
from dataset import Dataset
from metrics import iou_score
from metrics import dice_coef
from utils import AverageMeter

import time
from torchsummary import summary


def parse_args():
    parser = argparse.ArgumentParser()

    parser.add_argument('--name', default='brain_UNet_woDS',
                        help='model name') # made default from None to covid_UNet_woDS

    args = parser.parse_args()

    return args


def main():
    args = parse_args()

    with open('models/%s/config.yml' % args.name, 'r') as f:
        config = yaml.load(f, Loader=yaml.FullLoader)

    print('-'*20)
    for key in config.keys():
        print('%s: %s' % (key, str(config[key])))
    print('-'*20)

    cudnn.benchmark = True

    # create model
    print("=> creating model %s" % config['arch'])
    model = archs.__dict__[config['arch']](config['num_classes'],
                                           config['input_channels']) #,
                                           #config['deep_supervision']) #3rd argument hashed for U-Net

    model = model.cuda()

    # Data loading code
    val_img_ids = glob(os.path.join('testinput', config['dataset'], 'images', '*' + config['img_ext']))
    val_img_ids = [os.path.splitext(os.path.basename(p))[0] for p in val_img_ids]

    #_, val_img_ids = train_test_split(img_ids, test_size=0.96, random_state=41)

    # checkpoint = torch.load('models/%s/model.pth' %
    #                                  config['name'])
    # model.load_state_dict(checkpoint['model'])


    model.load_state_dict(torch.load('models/%s/model.pth' %
                                     config['name']))
    model.eval()

    val_transform = Compose([
         albu.Resize(config['input_h'], config['input_w']),
         albu.Normalize(),
     ])

    val_dataset = Dataset(
        img_ids=val_img_ids,
        img_dir=os.path.join('testinput', config['dataset'], 'images'),
        mask_dir=os.path.join('testinput', config['dataset'], 'masks'),
        img_ext=config['img_ext'],
        mask_ext=config['mask_ext'],
        num_classes=config['num_classes'],
        transform=val_transform)
    val_loader = torch.utils.data.DataLoader(
        val_dataset,
        batch_size=config['batch_size'],
        shuffle=False,
        num_workers=config['num_workers'],
        drop_last=False)

    avg_meter = AverageMeter()

    for c in range(config['num_classes']):
        os.makedirs(os.path.join('outputs', config['name'], str(c)), exist_ok=True)
    
    file = open("files/test_results.csv", "w")
    file.write("Mean Time,Mean FPS\n")
    time_taken = []
    with torch.no_grad():
        for input, target, meta in tqdm(val_loader, total=len(val_loader)):
            input = input.cuda()
            target = target.cuda()
            #print(input.size())
            # compute output
            """ FPS Calculation """
            start_time = time.time()
            if config['deep_supervision']:
                output = model(input)[-1]
            else:
                output = model(input)
            # iou = iou_score(output, target)
            # avg_meter.update(iou, input.size(0))
            end_time = time.time() - start_time # AShwini: FPS calculation is done for prefiction model run (reciprocal of mean time taken in predicting one mask)
            time_taken.append(end_time)
            
            dice = dice_coef(output,target)
            avg_meter.update(dice, input.size(0))

            output = torch.sigmoid(output).cpu().numpy()  
            #output = torch.softmax(output, dim=0).cpu().numpy() #(Used Softmax to make masks multi-class and normalising the first axix of output tensor)
            #output = torch.tanh(output) #.cpu().numpy()
            #output = output.cpu().numpy()

            #dice = dice_coef(output,target)
            #avg_meter.update(dice, input.size(0))


            for i in range(len(output)):
                for c in range(config['num_classes']):
                    cv2.imwrite(os.path.join('outputs', config['name'], str(c), meta['img_id'][i] + '.png'),
                                (output[i, c] * 255).astype('uint8'))
        
        #--------FPS Calculation-------------------------
        """ Mean Time Calculation """
        mean_time_taken = np.mean(time_taken)
        print("Mean Time Taken: ", mean_time_taken)
        mean_fps = 1/mean_time_taken
        print(f"Mean Time: {mean_time_taken:1.7f} - Mean FPS: {mean_fps:1.7f}")
        save_str = f"{mean_time_taken:1.7f},{mean_fps:1.7f}\n"
        file.write(save_str)
        #-------------------------------------------
    #print('IoU: %.4f' % avg_meter.avg)
    print('Dice: %.4f' % avg_meter.avg)

    torch.cuda.empty_cache()

    #----------Calculation of parameters & Flops-------------------------
    # Print model summary to get parameter size
    test_model = model
    summary_info = summary(test_model, input_size=(1,256,256), dtypes=torch.float) #modified this to include for multiple inputs
    # Calculate FLOPs
    test_input = torch.randn(1, 3, 256, 256).cuda()
    #mask_input = torch.randn(1,1,480,480).cuda()
    flops, params = profile(test_model, inputs=(test_input,))
    print("FLOPs: ", flops)
    print("Params: ", params)

    #Saving parameters and FLOPs in a CSV file
    with open('files/model_summary.csv', 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        #writer.writerow(['Layer (type)', 'Output Shape', 'Param #'])
        #for layer in summary_info:
        writer.writerow(['Summary', summary_info])
        writer.writerow(['FLOPs', flops])
        writer.writerow(['Params', params])
    #----------------------------------------------------------------


if __name__ == '__main__':
    main()
